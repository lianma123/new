
var title =
    '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 one authors">网友</div>'+
    '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5  one id">标题</div>'+
    '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 one name">点击量</div>'+
    '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 one age">回复量</div>'+
    '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 one school">发送日期</div>'+
    '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 one professional">更新时间</div>';
$(".title").append(title);

var data = ["24小时","近一月","近三月","近六月","近一年","近三年"];
//筛选框展示
$.each(data, function(idx,obj){
    var se_html = '<option value="'+obj+'">'+obj+'</option>';
    $(".select").append(se_html);
});

var clicks=[];    //类别数组（实际用来盛放X轴坐标值）
var authors=[];    //销量数组（实际用来盛放Y坐标值）
var replys=[];    //类别数组（实际用来盛放X轴坐标值）
var titles=[];    //销量数组（实际用来盛放Y坐标值）
var lastdatas=[];    //类别数组（实际用来盛放X轴坐标值）
var senddatas=[];    //销量数组（实际用来盛放Y坐标值）
//查询方法
$(".query").on('click',function(){
    var name = $("#select_school").val();
    console.log(name);
    $.ajax({
        type: "GET",
        url:"list",
        async: true,
        cache:false,
        data: {'name':name},
        dataType:"json",

        success: function(result) {
            console.log(name);
            var data = result.data;
            if(data){
                for(var i=0;i<data.length;i++){
                    clicks.push(data[i].click);    //挨个取出类别并填入类别数组
                }
                for(var i=0;i<data.length;i++){
                    authors.push(data[i].author);    //挨个取出销量并填入销量数组
                }
                for(var i=0;i<data.length;i++){
                    replys.push(data[i].reply);    //挨个取出类别并填入类别数组
                }
                for(var i=0;i<data.length;i++){
                    titles.push(data[i].title);    //挨个取出销量并填入销量数组
                }
                for(var i=0;i<data.length;i++){
                    senddatas.push(data[i].senddata);    //挨个取出类别并填入类别数组
                }
                for(var i=0;i<data.length;i++){
                    lastdatas.push(data[i].lastdata);    //挨个取出销量并填入销量数组
                }
            }
            for(var i=0;i<titles.length;i++){
                var detail ='<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 page_detail">'+
                    '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 one authors ">'+'<a href="http://www.xqfunds.com/">'+authors[i]+'</a>'+'</div>'+
                    '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5 one id">'+titles[i]+'</div>'+
                    '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 one name">'+clicks[i]+'</div>'+
                    '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 one age">'+replys[i]+'</div>'+
                    '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 one school">'+senddatas[i]+'</div>'+
                    '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 one professional">'+lastdatas[i]+'</div>';
                $(".page_info").append(detail);}
        }
    });
});
function myfun(){

    $.getJSON({
        type: "GET",
        url:"list",
        async: false,
        cache:false,
        dataType:"json",
        success: function(result) {
            var data = result.data;
            if(data){
                for(var i=0;i<data.length;i++){
                    clicks.push(data[i].click);    //挨个取出类别并填入类别数组
                }
                for(var i=0;i<data.length;i++){
                    authors.push(data[i].author);    //挨个取出销量并填入销量数组
                }
                for(var i=0;i<data.length;i++){
                    replys.push(data[i].reply);    //挨个取出类别并填入类别数组
                }
                for(var i=0;i<data.length;i++){
                    titles.push(data[i].title);    //挨个取出销量并填入销量数组
                }
                for(var i=0;i<data.length;i++){
                    senddatas.push(data[i].senddata);    //挨个取出类别并填入类别数组
                }
                for(var i=0;i<data.length;i++){
                    lastdatas.push(data[i].lastdata);    //挨个取出销量并填入销量数组
                }
            }
            for(var i=0;i<titles.length;i++){
            var detail ='<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 page_detail">'+
                '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 one authors ">'+'<a href="http://www.xqfunds.com/">'+authors[i]+'</a>'+'</div>'+
                '<div class="col-lg-5 col-md-5 col-sm-5 col-xs-5 one id">'+titles[i]+'</div>'+
                '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 one name">'+clicks[i]+'</div>'+
                '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 one age">'+replys[i]+'</div>'+
                '<div class="col-lg-1 col-md-1 col-sm-1 col-xs-1 one school">'+senddatas[i]+'</div>'+
                '<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 one professional">'+lastdatas[i]+'</div>';
            $(".page_info").append(detail);}
        }
    });
};
window.onload = myfun;










